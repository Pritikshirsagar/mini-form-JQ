<?php
 $con=mysqli_connect('localhost','root');
/* if($con){
 	echo "success";
 }*/
 $db=mysqli_select_db($con,'formdb');
/*if($db){
 	echo "hii";
 }*/
$nameid = $_POST['datapost'];
$q ="select * from classses where mid='$nameid'";
$result = mysqli_query($con,$q);



while($rows = mysqli_fetch_array($result)) {
							?>

						<option> <?php echo $rows['class']?></option>

							<?php

						}

?>