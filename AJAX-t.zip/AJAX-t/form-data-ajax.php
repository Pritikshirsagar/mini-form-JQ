<?php
 $con=mysqli_connect('localhost','root');
/* if($con){
 	echo "success";
 }*/
 $db=mysqli_select_db($con,'formdb');
/*if($db){
 	echo "hii";
 }*/

?>
<!DOCTYPE html>
<html>
<head>
	<title>Form Data using Ajax </title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

</head>
<body>
	<div class="container col-lg-6">
		<h2 class="text-center text-danger">Get data from database</h2>
		<form>
			
			username:<input type="text" name="" class="form-control"><br>
			password:<input type="password" name="" class="form-control"><br>

			Degree:<select class="form-control" onchange="myfun(this.value)">
				<option>Select Anyone</option>
				<?php
						$q ="select * from degree";
						$result = mysqli_query($con,$q);
						while($rows = mysqli_fetch_array($result)) {
							?>

						<option value="<?php echo $rows['mid']?>"> <?php echo $rows['degrees']?></option>

							<?php

						}

				?>
			</select><br>
			Class:<select class="form-control" id="dataget">
				<option>Choose Any one </option>
			</select><br>

			<button class="btn btn-primary">Submit</button>
		</form>
		

	</div>
<script type="text/javascript">
	
	function myfun(datavalue){

		$.ajax({

				url:'class.php',
				type:'POST',
				data:{ datapost:datavalue },

				success: function(result){
					$('#dataget').html(result);
				}
		});
	}
</script>
</body>
</html>